

	<div id="data_pribadi" class="point_list">
		Hobbies
	</div>

	<div class="content_list">
		<table>
			<?=$tr_hobby ?>
			<tr <?=$hobby1_view ?>>
				<td><img src="../assets/img/icons/heart.png" width="20px" height="20px"></td>
				<td><?=$hobby1_show ?></td>
			</tr>
			<tr <?=$hobby2_view ?>>
				<td><img src="../assets/img/icons/heart.png" width="20px" height="20px"></td>
				<td><?=$hobby2_show ?></td>
			</tr>
			<tr <?=$hobby3_view ?>>
				<td><img src="../assets/img/icons/heart.png" width="20px" height="20px"></td>
				<td><?=$hobby3_show ?></td>
			</tr>
			<tr <?=$hobby4_view ?>>
				<td><img src="../assets/img/icons/heart.png" width="20px" height="20px"></td>
				<td><?=$hobby4_show ?></td>
			</tr>
			<tr <?=$hobby5_view ?>>
				<td><img src="../assets/img/icons/heart.png" width="20px" height="20px"></td>
				<td><?=$hobby5_show ?></td>
			</tr>
		</table>
	</div>

	<div id="data_pribadi" class="point_list">
		Cita-cita
	</div>

	<div class="content_list">
		<table>
			<?=$tr_cita ?>
			<tr <?=$cita1_view ?>>
				<td><img src="../assets/img/icons/trophy.png" width="20px" height="20px"></td>
				<td><?=$cita1_show ?></td>
			</tr>
			<tr <?=$cita2_view ?>>
				<td><img src="../assets/img/icons/trophy.png" width="20px" height="20px"></td>
				<td><?=$cita2_show ?></td>
			</tr>
			<tr <?=$cita3_view ?>>
				<td><img src="../assets/img/icons/trophy.png" width="20px" height="20px"></td>
				<td><?=$cita3_show ?></td>
			</tr>
		</table>
	</div>

</div>