<div id="blok_cita-cita" class="blok">
	<div class="content_list">

		<div class="db_var">
			cita1 <input id="db_cita1" value="<?=$cita1?>">
			<br>cita2 <input id="db_cita2" value="<?=$cita2?>">
			<br>cita3 <input id="db_cita3" value="<?=$cita3?>">
		</div>

		<p>Masukan 3 cita-cita terbesarmu! !</p>

		<table class="table table-hover">
			<tr>
				<td width="25%"><b> Cita-cita #1</b></td>
				<td>
					<input type="text" maxlength="30" id="cita1" class="form-control input_text" value="<?=$cita1 ?>">
				</td>
			</tr>
			<tr>
				<td width="25%"><b> Cita-cita #2</b></td>
				<td>
					<input type="text" maxlength="30" id="cita2" class="form-control input_text" value="<?=$cita2 ?>">
				</td>
			</tr>
			<tr>
				<td width="25%"><b> Cita-cita #3</b></td>
				<td>
					<input type="text" maxlength="30" id="cita3" class="form-control input_text" value="<?=$cita3 ?>">
				</td>
			</tr>
		</table>

	</div>
</div>
