<div id="blok_testimony" class="blok">
	<div class="content_list">

		<h4>Testimony Manager</h4>
		<p>Testimony Manager masih dalam tahap pengembangan. Terimakasih.</p>
		<!-- <table class="table table-hover">
			<tr>
				<td width="25%"><b>Level</b></td>
				<td>
					<input type="text" class="form-control">
				</td>
			</tr>
			<tr>
				<td><b>Developer Type</b></td>
				<td>Frontend Developer</td>
			</tr>
			<tr>
				<td><b>Badges</b></td>
				<td>CSS-Warrior, JS-Novice, PHP-Advanced</td>
			</tr>
		</table> -->

	</div>
</div>