<div id="blok_skill_lainnya" class="blok">
	<div class="content_list">

		<div class="db_var">
			skilla1 <input id="db_skilla1" value="<?=$skilla1?>">
			<br>skilla2 <input id="db_skilla2" value="<?=$skilla2?>">
			<br>skilla3 <input id="db_skilla3" value="<?=$skilla3?>">
			<br>skilla4 <input id="db_skilla4" value="<?=$skilla4?>">
			<br>skilla5 <input id="db_skilla5" value="<?=$skilla5?>">
		</div>

		<p>Masukan Level Skill dengan angka antara 0 s.d 100 !</p>

		<table class="table table-hover">
			<tr>
				<td width="25%"><b> Elektronika / Microcontroller</b></td>
				<td>
					<input type="number" min="0" max="100" id="skilla1" class="form-control input_text" value="<?=$skilla1 ?>">
				</td>
			</tr>
			<tr>
				<td width="25%"><b> Seni Bela Diri</b></td>
				<td>
					<input type="number" min="0" max="100" id="skilla2" class="form-control input_text" value="<?=$skilla2 ?>">
				</td>
			</tr>
			<tr>
				<td width="25%"><b> Survival / Tim SAR</b></td>
				<td>
					<input type="number" min="0" max="100" id="skilla3" class="form-control input_text" value="<?=$skilla3 ?>">
				</td>
			</tr>
			<tr>
				<td width="25%"><b> Skill Medis</b></td>
				<td>
					<input type="number" min="0" max="100" id="skilla4" class="form-control input_text" value="<?=$skilla4 ?>">
				</td>
			</tr>
			<tr>
				<td width="25%"><b> Skill Profesional Lainnya</b></td>
				<td>
					<input type="number" min="0" max="100" id="skilla5" class="form-control input_text" value="<?=$skilla5 ?>">
				</td>
			</tr>
		</table>

	</div>
</div>
