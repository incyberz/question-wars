

<div id="data_pribadi" class="point_list_right">
	Riwayat Pendidikan
</div>

<div class="content_list">
	<table class="table table-hover">
		<tr <?=$riwayat_pendidikan1_view ?>>
			<td width="25%"><b><?=$rriwayat_pendidikan1[0] ?> - <?=$rriwayat_pendidikan1[1] ?></b></td>
			<td><?=$rriwayat_pendidikan1[2] ?></td>
			<td width="25%"><?=$rriwayat_pendidikan1[3] ?></td>
		</tr>
		<tr <?=$riwayat_pendidikan2_view ?>>
			<td width="25%"><b><?=$rriwayat_pendidikan2[0] ?> - <?=$rriwayat_pendidikan2[1] ?></b></td>
			<td><?=$rriwayat_pendidikan2[2] ?></td>
			<td width="25%"><?=$rriwayat_pendidikan2[3] ?></td>
		</tr>
		<tr <?=$riwayat_pendidikan3_view ?>>
			<td width="25%"><b><?=$rriwayat_pendidikan3[0] ?> - <?=$rriwayat_pendidikan3[1] ?></b></td>
			<td><?=$rriwayat_pendidikan3[2] ?></td>
			<td width="25%"><?=$rriwayat_pendidikan3[3] ?></td>
		</tr>
		<tr <?=$riwayat_pendidikan4_view ?>>
			<td width="25%"><b><?=$rriwayat_pendidikan4[0] ?> - <?=$rriwayat_pendidikan4[1] ?></b></td>
			<td><?=$rriwayat_pendidikan4[2] ?></td>
			<td width="25%"><?=$rriwayat_pendidikan4[3] ?></td>
		</tr>
		<tr <?=$riwayat_pendidikan5_view ?>>
			<td width="25%"><b><?=$rriwayat_pendidikan5[0] ?> - <?=$rriwayat_pendidikan5[1] ?></b></td>
			<td><?=$rriwayat_pendidikan5[2] ?></td>
			<td width="25%"><?=$rriwayat_pendidikan5[3] ?></td>
		</tr>
	</table>
</div>



<div id="data_pribadi" class="point_list_right">
	Riwayat Pekerjaan
</div>

<div class="content_list">
	<table class="table table-hover">
		<tr <?=$riwayat_pekerjaan1_view ?>>
			<td width="25%"><b><?=$rriwayat_pekerjaan1[0] ?> - <?=$rriwayat_pekerjaan1[1] ?></b></td>
			<td><?=$rriwayat_pekerjaan1[2] ?></td>
			<td width="25%"><?=$rriwayat_pekerjaan1[3] ?></td>
		</tr>
		<tr <?=$riwayat_pekerjaan2_view ?>>
			<td width="25%"><b><?=$rriwayat_pekerjaan2[0] ?> - <?=$rriwayat_pekerjaan2[1] ?></b></td>
			<td><?=$rriwayat_pekerjaan2[2] ?></td>
			<td width="25%"><?=$rriwayat_pekerjaan2[3] ?></td>
		</tr>
		<tr <?=$riwayat_pekerjaan3_view ?>>
			<td width="25%"><b><?=$rriwayat_pekerjaan3[0] ?> - <?=$rriwayat_pekerjaan3[1] ?></b></td>
			<td><?=$rriwayat_pekerjaan3[2] ?></td>
			<td width="25%"><?=$rriwayat_pekerjaan3[3] ?></td>
		</tr>
		<tr <?=$riwayat_pekerjaan4_view ?>>
			<td width="25%"><b><?=$rriwayat_pekerjaan4[0] ?> - <?=$rriwayat_pekerjaan4[1] ?></b></td>
			<td><?=$rriwayat_pekerjaan4[2] ?></td>
			<td width="25%"><?=$rriwayat_pekerjaan4[3] ?></td>
		</tr>
		<tr <?=$riwayat_pekerjaan5_view ?>>
			<td width="25%"><b><?=$rriwayat_pekerjaan5[0] ?> - <?=$rriwayat_pekerjaan5[1] ?></b></td>
			<td><?=$rriwayat_pekerjaan5[2] ?></td>
			<td width="25%"><?=$rriwayat_pekerjaan5[3] ?></td>
		</tr>
	</table>
</div>



<div id="data_pribadi" class="point_list_right">
	Riwayat Organisasi
</div>

<div class="content_list">
	<table class="table table-hover">
		<tr <?=$riwayat_organisasi1_view ?>>
			<td width="25%"><b><?=$rriwayat_organisasi1[0] ?> - <?=$rriwayat_organisasi1[1] ?></b></td>
			<td><?=$rriwayat_organisasi1[2] ?></td>
			<td width="25%"><?=$rriwayat_organisasi1[3] ?></td>
		</tr>
		<tr <?=$riwayat_organisasi2_view ?>>
			<td width="25%"><b><?=$rriwayat_organisasi2[0] ?> - <?=$rriwayat_organisasi2[1] ?></b></td>
			<td><?=$rriwayat_organisasi2[2] ?></td>
			<td width="25%"><?=$rriwayat_organisasi2[3] ?></td>
		</tr>
		<tr <?=$riwayat_organisasi3_view ?>>
			<td width="25%"><b><?=$rriwayat_organisasi3[0] ?> - <?=$rriwayat_organisasi3[1] ?></b></td>
			<td><?=$rriwayat_organisasi3[2] ?></td>
			<td width="25%"><?=$rriwayat_organisasi3[3] ?></td>
		</tr>
		<tr <?=$riwayat_organisasi4_view ?>>
			<td width="25%"><b><?=$rriwayat_organisasi4[0] ?> - <?=$rriwayat_organisasi4[1] ?></b></td>
			<td><?=$rriwayat_organisasi4[2] ?></td>
			<td width="25%"><?=$rriwayat_organisasi4[3] ?></td>
		</tr>
		<tr <?=$riwayat_organisasi5_view ?>>
			<td width="25%"><b><?=$rriwayat_organisasi5[0] ?> - <?=$rriwayat_organisasi5[1] ?></b></td>
			<td><?=$rriwayat_organisasi5[2] ?></td>
			<td width="25%"><?=$rriwayat_organisasi5[3] ?></td>
		</tr>
	</table>
</div>



<div id="data_pribadi" class="point_list_right">
	Sertifikasi / Training
</div>

<div class="content_list">
	<table class="table table-hover">
		<tr <?=$riwayat_sertifikasi1_view ?>>
			<td width="25%"><b><?=$rriwayat_sertifikasi1[0] ?> - <?=$rriwayat_sertifikasi1[1] ?></b></td>
			<td><?=$rriwayat_sertifikasi1[2] ?></td>
			<td width="25%"><?=$rriwayat_sertifikasi1[3] ?></td>
		</tr>
		<tr <?=$riwayat_sertifikasi2_view ?>>
			<td width="25%"><b><?=$rriwayat_sertifikasi2[0] ?> - <?=$rriwayat_sertifikasi2[1] ?></b></td>
			<td><?=$rriwayat_sertifikasi2[2] ?></td>
			<td width="25%"><?=$rriwayat_sertifikasi2[3] ?></td>
		</tr>
		<tr <?=$riwayat_sertifikasi3_view ?>>
			<td width="25%"><b><?=$rriwayat_sertifikasi3[0] ?> - <?=$rriwayat_sertifikasi3[1] ?></b></td>
			<td><?=$rriwayat_sertifikasi3[2] ?></td>
			<td width="25%"><?=$rriwayat_sertifikasi3[3] ?></td>
		</tr>
		<tr <?=$riwayat_sertifikasi4_view ?>>
			<td width="25%"><b><?=$rriwayat_sertifikasi4[0] ?> - <?=$rriwayat_sertifikasi4[1] ?></b></td>
			<td><?=$rriwayat_sertifikasi4[2] ?></td>
			<td width="25%"><?=$rriwayat_sertifikasi4[3] ?></td>
		</tr>
		<tr <?=$riwayat_sertifikasi5_view ?>>
			<td width="25%"><b><?=$rriwayat_sertifikasi5[0] ?> - <?=$rriwayat_sertifikasi5[1] ?></b></td>
			<td><?=$rriwayat_sertifikasi5[2] ?></td>
			<td width="25%"><?=$rriwayat_sertifikasi5[3] ?></td>
		</tr>
	</table>
</div>


