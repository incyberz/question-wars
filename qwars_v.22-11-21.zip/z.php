<?php 
$total_player = 0;
$jumlah_player_in_kelas = 0;
$jumlah_player_in_prodi = 0;

$rank_player = 0;
$rank_player_in_kelas = 0;
$rank_player_in_prodi = 0;

// $nama_badge = "-";


# ================================================
# ROOM_VARS :: PRESENSI
$jumlah_presensi = 0;
$total_presensi_saat_ini = 0;

# ================================================
# ROOM_VARS :: SOAL
$jumlah_soal_publish = 0;
$jumlah_soal_banned = 0;
$jumlah_soal_suspend = 0;
$jumlah_soal_new = 0;
$total_soal = 0;

# ================================================
# ROOM_VARS :: CHALLENGES
$jumlah_chal = 0;
$jumlah_chal_unclaim = 0;
$jumlah_chal_claimed = 0;
$jumlah_chal_unver = 0;
// $jumlah_chal_point = 0;
$total_chal = 0;
$total_chal_point = 0;

# ================================================
# ROOM_VARS :: CHALLENGE TUGAS
$jumlah_tugas = 0;
$total_tugas = 0;


# ================================================
# OTHER ACTIVITY
$jumlah_play = 0;
$jumlah_play_benar = 0;
$jumlah_play_salah = 0;
$jumlah_play_timed_out = 0;
$jumlah_reject = 0;
$jumlah_daily_login = 0;

$total_play_kuis = 0;
$total_aktif_player = 0;

# ================================================
# OUTPUT PERSEN
$persen_presensi = 0;
$persen_akurasi = 0;
$persen_chal = 0;

 ?>