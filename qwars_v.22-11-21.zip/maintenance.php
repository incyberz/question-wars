<section id="hero" class="visitor">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-8">
				<h2 class="awesome">Maaf, kawan-kawan!!</h2>
				<h1 class="subawesome">Server sedang maintenance !</h1>
				<hr>
				<p style="color:yellow;"><?=$ket_maintenance?></p>
				<p>Mohon kawan-kawan bersabar!</p>
			</div>
		</div>
	</div>
</section>

<?php exit(); ?>