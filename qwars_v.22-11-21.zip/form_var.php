<?php 
$btn_path = "<img src='assets/img/icons";

$btn_style = " width='25px' style='border: solid 1px white;background-color: white; border-radius: 5px; padding: 1px'>";
$btn_style2 = " height='20px' style='background-color: white; padding: 2px'>";

$btn_edit = "$btn_path/edit.png' $btn_style";
$btn_delete = "$btn_path/delete.png' $btn_style";
$btn_delete2 = "$btn_path/delete.png' $btn_style2";
$btn_add = "$btn_path/add.png' $btn_style";
$btn_update = "$btn_path/update.png' $btn_style";
$btn_disabled = "$btn_path/disabled.png' $btn_style";

?>