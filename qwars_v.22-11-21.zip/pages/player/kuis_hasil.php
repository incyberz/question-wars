<!-- <section id="kuis_hasil" class="player hideita">
	<div class="container">

		<div class="col-lg-6" id="blok_hasil_kuis">
		  <table class="table table-bordered table-hover"  style='background-color: pink' >
		    <thead>
		      <th style="text-align: center">Quiz Result</th>
		    </thead>
		    <tr>
		      <td>
		        <h2 align="center"><font color=red>Kamu Kurang Tepat !!</font></h2>
		        <p style="font-size: 10pt">
		          Untuk menghapus window dan memberi warna yang telah kita definisikan sebelumnya dapat menggunakan...
		          <br>a. glColor3f
		          <br>b. glCleanColor
		          <br>c. glPushMatrix
		          <br>d. glPopMatrix
		          <br>e. glClearColor
		          <hr>Jawaban kamu: C, seharusnya jawab E 
		          | <a href='?p=lapor_soal&id_soal=763' target='_blank'>Laporkan Kesalahan</a>
		        </p>

		        <hr>
		        <h3 align="center">Kamu mendapat 8 Learning Point</h3>
		        <p align="center">Rows Point  : 0 LP</p>
		        <p align="center">Creator Point : 15.75 LP</p>
		        <hr>
		        <p align="center">Your Points : 1399.09 LP</p>
		        <p align="center">Your New Points : 1407.09 LP</p>


		      </td>
		    </tr>
		    <tr>
		      <td>
		      	<div class="row">
		      		<div class="col-lg-6" style="margin-bottom: 8px">
		      		  <a href="?p=pl_ldb" class="btn btn-primary btn-block">Leaderboard</a>
		      		</div>
		      		<div class="col-lg-6">
		      		  <form method="POST">
		      		    <input type="hidden" name="row_answer_before" value="0">
		      		    <button class="btn btn-primary btn-block" id="btn_next_question" name="btn_next_question"  disabled >Next Question</button>
		      		  </form>
		      		</div>

		      	</div>
		        
		      </td>
		    </tr>
		    
		  </table>
		  
		</div>

	</div>
</section> -->