<section id="info_materi_kuliah" class="player hideit">
	<div class="container">

		<h3>Materi Kuliah</h3>

		<p>
[Prototype Mode] Fitur masih dalam tahap pengembangan...</p>

	</div>
</section>