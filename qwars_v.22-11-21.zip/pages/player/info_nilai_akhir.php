<section id="info_nilai_akhir" class="player hideit">
	<div class="container">

		<h3>Nilai Akhir</h3>

		<p>
[Prototype Mode] Fitur masih dalam tahap pengembangan...</p>

	</div>
</section>