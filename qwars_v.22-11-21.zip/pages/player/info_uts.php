<section id="info_uts" class="player hideit">
	<div class="container">

		<h3>Info UTS</h3>

		<p>
[Prototype Mode] Fitur masih dalam tahap pengembangan...</p>

	</div>
</section>