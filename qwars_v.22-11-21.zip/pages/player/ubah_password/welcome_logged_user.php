<h4>Welcome <?=$cnama_user?>!!</h4>
<p>
	<a href="logout.php" onclick="return confirm('Yakin untuk logout?')">Logout</a> | 
	Anda login sebagai <?=$cjenis_user ?>.
</p>
<hr>