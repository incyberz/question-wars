<section class="player dashboard">
	<div class="container">

<div style="border:solid 1px #ccc; border-radius:15px;padding: 15px;">
	<p>Cara untuk meningkatkan Rank yaitu dengan mengumpulkan point activity atau Learning Point (LP). Semakin banyak poin yang kamu kumpulkan akan semakin tinggi Rank kamu. Cara untuk mendapatkan poin yaitu dengan cara melakukan activity. List activity diantaranya:</p>
	<ol>
		<li>Daily Login (Login setiap hari)</li>
		<li>Beat Question (menjawab soal dari GM atau yang dibuat oleh kawanmu)</li>
		<li>Create Question. Buatlah soal yang sulit agar menghasilkan Passive Poin yang besar.</li>
		<li>Beat Challenge (mengupload bukti kamu menguasai challenge dari GM)</li>
		<li>Passive Poin (ketika soal kamu dijawab oleh kawanmu akan memberikan persentase poin untuk kamu)</li>
		<li>Bonus Poin. Saat kamu melengkapi profil kamu, menjawab soal secara berurutan atau login setiap hari maka kamu akan mendapatkan bonus poin sebesar 1 s.d 20% dari poin activity.</li>
	</ol>
	<a href="?" class="btn btn-primary btn-sm">OK. Saya faham</a>

</div>


</div>
</section>