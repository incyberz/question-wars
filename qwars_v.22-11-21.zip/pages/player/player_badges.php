<section id="player_badges" class="player hideit">
	<div class="container">

		<h3>Player Badges</h3>

		<p>
[Prototype Mode] Fitur masih dalam tahap pengembangan...</p>

	</div>
</section>