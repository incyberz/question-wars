<script type="text/javascript">
	$(document).ready(function(){
		// =========================================
		// SOAL TIMER
		// =========================================
		// let durasi_jawab = $('#durasi_jawab').val();


		// const timer = setInterval(function(){
		// 	let sisa_waktu = parseInt($('#sisa_waktu').text());
			
		// 	// console.log(`setInterval sisa_waktu: ${sisa_waktu}`);
		// 	// =========================================
		// 	// BATALKAN TIMER JIKA USER SUDAH MENJAWAB
		// 	// =========================================
		// 	let jawaban_terpilih = $('#jawaban_terpilih').val();
		// 	let jawaban_seharusnya = $('#jawaban_seharusnya').val();
		// 	if(jawaban_terpilih==jawaban_seharusnya && jawaban_terpilih!=''){
		// 		clearInterval(timer);
		// 		return;
		// 	}

		// 	if(sisa_waktu == 0){
		// 		clearInterval(timer);
		// 		cek_jawaban();
		// 	}else{
		// 		sisa_waktu--;
		// 		console.log(`setInterval sisa_waktu--: ${sisa_waktu}`);
		// 		$('#sisa_waktu').text(sisa_waktu);
		// 	}
		// },1000);

	})
</script>