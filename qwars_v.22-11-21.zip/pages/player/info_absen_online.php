<section id="info_absen_online" class="player hideit">
	<div class="container">

		<h3>Absen Online</h3>

		<p>
[Prototype Mode] Fitur masih dalam tahap pengembangan...</p>

	</div>
</section>