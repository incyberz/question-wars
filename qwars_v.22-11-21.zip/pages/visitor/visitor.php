<?php 
# INDEX OF USER ==========================
include 'hero.php';
// include 'login.php';
include 'pages/player/realtime_wars/realtime_wars.php';
include 'about.php';
include 'counts.php';
// include 'our_games.php';
// include 'cta.php';
// include 'features.php';
// include 'clients.php';
// include 'portfolio.php';
// include 'pricing.php';
include 'faq.php';
// include 'contact.php';

?>