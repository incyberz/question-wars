<section id="hero" class="visitor d-flex flex-column justify-content-center" style="display: none">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-8">
        <h1>Dingo - Digital Learning with Gamifications</h1>
        <h2>Make learning as fun as playing !</h2>
        <a href="#" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
      </div>
    </div>
  </div>
</section>