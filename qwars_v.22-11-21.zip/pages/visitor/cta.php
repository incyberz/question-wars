<section id="duel_soal" class="visitor cta">
  <div class="container">

    <div class="row">
      <div class="col-lg-9 text-center text-lg-left">
        <h3>Duel Soal</h3>
        <p>Get points from make questions or answer your friends questions. Make sure you make difficult questions for more earned points when your friends answered falsely. It's like </p>
      </div>
      <div class="col-lg-3 cta-btn-container text-center">
        <a class="cta-btn align-middle" href="#">Play Duel Soal</a>
      </div> 
    </div>

  </div>
</section>
