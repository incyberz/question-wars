<section id="clients" class="visitor clients" style="display: none">
  <div class="container">

    <div class="row no-gutters clients-wrap clearfix wow fadeInUp">

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-7.png" class="img-fluid" alt="">
        </div>
      </div>

      <div class="col-lg-3 col-md-4 col-xs-6">
        <div class="client-logo">
          <img src="assets/img/clients/client-8.png" class="img-fluid" alt="">
        </div>
      </div>

    </div>

  </div>
</section><!-- End Clients Section -->
