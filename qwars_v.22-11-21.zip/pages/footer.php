<footer id="footer">
  <div class="container">
    <h4>Question Wars Gamified Learning</h4>
    <p>Make Learning as fun as Playing !</p>
    <div class="social-links">
      <a href="https://www.twitter.com/incyberz/" class="twitter" onclick="return confirm('Programmer jarang cuit2 online. Mau lihat tweeternya?')" target="_blank"><i class="bx bxl-twitter"></i></a>
      <a href="https://www.facebook.com/incyberz/" class="facebook" onclick="return confirm('Programmer jarang buka fesbuk. Mau lihat fesbuknya?')" target="_blank"><i class="bx bxl-facebook"></i></a>
      <a href="https://github.com/incyberz/" class="github" onclick="return confirm('Menuju Laman Project programmer?')" target="_blank"><i class="bx bxl-github"></i></a>
      <a href="https://youtube.com/@ngampusonline" class="youtube" onclick="return confirm('Menuju Channel Youtube programmer?')" target="_blank"><i class="bx bxl-youtube"></i></a>
      <a href="https://www.linkedin.com/in/iin-sholihin-740522117" class="linkedin" onclick="return confirm('Menuju LinkedIn programmer?')" target="_blank"><i class="bx bxl-linkedin"></i></a>
    </div>
    <div class="copyright">
      &copy; There is no Copyright. All Rights Belongs to Allah
    </div>
    <div class="credits">
      <span style="color: black">Designed by <a href="https://bootstrapmade.com/" style="color: black">BootstrapMade</a></span>
    </div>
  </div>
</footer>